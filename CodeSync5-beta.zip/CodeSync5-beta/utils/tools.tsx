export const tools = [
  { image: "/assets/home/NodeJS.svg", name: "Node.js" },
  { image: "/assets/home/Database.svg", name: "Database" },
  { image: "/assets/home/ReactJS.svg", name: "React.js" },
  { image: "/assets/home/Python.svg", name: "Python" },
  { image: "/assets/home/Wordpress.svg", name: "Wordpress" },
  { image: "/assets/home/Flutter.svg", name: "Flutter" },
  { image: "/assets/home/NextJS.svg", name: "Next.Js" },
];
