export const companyName = "CodeSync5";
